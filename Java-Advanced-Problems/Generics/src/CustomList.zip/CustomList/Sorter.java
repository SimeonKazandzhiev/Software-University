package CustomList;

public class Sorter<T extends Comparable<T>> {
    public static void sort(CustomList list){
        // Bubble sort //
        for (int i = 0; i < list.size(); i++) {
            String element =(String)list.get(i);
            for (int j = i+ 1; j < list.size(); j++) {
                String nextElement =(String) list.get(j);
                if(element.compareTo(nextElement) > 0){
                    list.swap(i,j);
                }
            }
        }


    }
}
