package animals;

public interface ProduceSound {
    String produceSound();
}
