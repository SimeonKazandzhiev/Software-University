package hero;

public class SoulMaster extends DarkWizard{
    public SoulMaster(String username, int level) {
        super(username, level);
    }
}
