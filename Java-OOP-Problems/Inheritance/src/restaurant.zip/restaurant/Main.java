package restaurant;

public class Main {
    public static void main(String[] args) {


        Coffee coffee = new Coffee("La",50);

        System.out.println(coffee.getMilliliters());
        System.out.println(coffee.getPrice());
        System.out.println(coffee.getCaffeine());
    }
}
